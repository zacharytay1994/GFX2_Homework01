1. wsl
2. ./GFX2_Homework01.exe -d -r
3. -d to enable Validation
4. -r to enable Renderdoc